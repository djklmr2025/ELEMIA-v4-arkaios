import type { RequestInit, RequestInfo } from "./internal/builtin-types.mjs";
import type { PromiseOrValue, MergedRequestInit, FinalizedRequestInit } from "./internal/types.mjs";
export type { Logger, LogLevel } from "./internal/utils/log.mjs";
import * as Opts from "./internal/request-options.mjs";
import * as Errors from "./core/error.mjs";
import * as Uploads from "./core/uploads.mjs";
import * as API from "./resources/index.mjs";
import * as TopLevelAPI from "./resources/top-level.mjs";
import { AddParams, AddResponse, ProfileParams, ProfileResponse } from "./resources/top-level.mjs";
import { APIPromise } from "./core/api-promise.mjs";
import { ConnectionConfigureParams, ConnectionConfigureResponse, ConnectionCreateParams, ConnectionCreateResponse, ConnectionDeleteByIDParams, ConnectionDeleteByIDResponse, ConnectionDeleteByProviderParams, ConnectionDeleteByProviderResponse, ConnectionGetByIDResponse, ConnectionGetByTagParams, ConnectionGetByTagResponse, ConnectionImportParams, ConnectionImportResponse, ConnectionListDocumentsParams, ConnectionListDocumentsResponse, ConnectionListParams, ConnectionListResponse, ConnectionResourcesParams, ConnectionResourcesResponse, Connections } from "./resources/connections.mjs";
import { DocumentAddParams, DocumentAddResponse, DocumentBatchAddParams, DocumentBatchAddResponse, DocumentDeleteBulkParams, DocumentDeleteBulkResponse, DocumentGetResponse, DocumentListParams, DocumentListProcessingResponse, DocumentListResponse, DocumentUpdateParams, DocumentUpdateResponse, DocumentUploadFileParams, DocumentUploadFileResponse, Documents } from "./resources/documents.mjs";
import { Memories, MemoryForgetParams, MemoryForgetResponse, MemoryUpdateMemoryParams, MemoryUpdateMemoryResponse } from "./resources/memories.mjs";
import { Search, SearchDocumentsParams, SearchDocumentsResponse, SearchExecuteParams, SearchExecuteResponse, SearchMemoriesParams, SearchMemoriesResponse } from "./resources/search.mjs";
import { SettingGetResponse, SettingUpdateParams, SettingUpdateResponse, Settings } from "./resources/settings.mjs";
import { type Fetch } from "./internal/builtin-types.mjs";
import { HeadersLike, NullableHeaders } from "./internal/headers.mjs";
import { FinalRequestOptions, RequestOptions } from "./internal/request-options.mjs";
import { type LogLevel, type Logger } from "./internal/utils/log.mjs";
export interface ClientOptions {
    /**
     * Defaults to process.env['SUPERMEMORY_API_KEY'].
     */
    apiKey?: string | undefined;
    /**
     * Override the default base URL for the API, e.g., "https://api.example.com/v2/"
     *
     * Defaults to process.env['SUPERMEMORY_BASE_URL'].
     */
    baseURL?: string | null | undefined;
    /**
     * The maximum amount of time (in milliseconds) that the client should wait for a response
     * from the server before timing out a single request.
     *
     * Note that request timeouts are retried by default, so in a worst-case scenario you may wait
     * much longer than this timeout before the promise succeeds or fails.
     *
     * @unit milliseconds
     */
    timeout?: number | undefined;
    /**
     * Additional `RequestInit` options to be passed to `fetch` calls.
     * Properties will be overridden by per-request `fetchOptions`.
     */
    fetchOptions?: MergedRequestInit | undefined;
    /**
     * Specify a custom `fetch` function implementation.
     *
     * If not provided, we expect that `fetch` is defined globally.
     */
    fetch?: Fetch | undefined;
    /**
     * The maximum number of times that the client will retry a request in case of a
     * temporary failure, like a network error or a 5XX error from the server.
     *
     * @default 2
     */
    maxRetries?: number | undefined;
    /**
     * Default headers to include with every request to the API.
     *
     * These can be removed in individual requests by explicitly setting the
     * header to `null` in request options.
     */
    defaultHeaders?: HeadersLike | undefined;
    /**
     * Default query parameters to include with every request to the API.
     *
     * These can be removed in individual requests by explicitly setting the
     * param to `undefined` in request options.
     */
    defaultQuery?: Record<string, string | undefined> | undefined;
    /**
     * Set the log level.
     *
     * Defaults to process.env['SUPERMEMORY_LOG'] or 'warn' if it isn't set.
     */
    logLevel?: LogLevel | undefined;
    /**
     * Set the logger.
     *
     * Defaults to globalThis.console.
     */
    logger?: Logger | undefined;
}
/**
 * API Client for interfacing with the Supermemory API.
 */
export declare class Supermemory {
    #private;
    apiKey: string;
    baseURL: string;
    maxRetries: number;
    timeout: number;
    logger: Logger;
    logLevel: LogLevel | undefined;
    fetchOptions: MergedRequestInit | undefined;
    private fetch;
    protected idempotencyHeader?: string;
    private _options;
    /**
     * API Client for interfacing with the Supermemory API.
     *
     * @param {string | undefined} [opts.apiKey=process.env['SUPERMEMORY_API_KEY'] ?? undefined]
     * @param {string} [opts.baseURL=process.env['SUPERMEMORY_BASE_URL'] ?? https://api.supermemory.ai] - Override the default base URL for the API.
     * @param {number} [opts.timeout=1 minute] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {MergedRequestInit} [opts.fetchOptions] - Additional `RequestInit` options to be passed to `fetch` calls.
     * @param {Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {HeadersLike} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Record<string, string | undefined>} opts.defaultQuery - Default query parameters to include with every request to the API.
     */
    constructor({ baseURL, apiKey, ...opts }?: ClientOptions);
    /**
     * Create a new client instance re-using the same options given to the current client with optional overriding.
     */
    withOptions(options: Partial<ClientOptions>): this;
    /**
     * Add a document with any content type (text, url, file, etc.) and metadata
     */
    add(body: TopLevelAPI.AddParams, options?: RequestOptions): APIPromise<TopLevelAPI.AddResponse>;
    /**
     * Get user profile with optional search results
     */
    profile(body: TopLevelAPI.ProfileParams, options?: RequestOptions): APIPromise<TopLevelAPI.ProfileResponse>;
    protected defaultQuery(): Record<string, string | undefined> | undefined;
    protected validateHeaders({ values, nulls }: NullableHeaders): void;
    protected authHeaders(opts: FinalRequestOptions): Promise<NullableHeaders | undefined>;
    /**
     * Basic re-implementation of `qs.stringify` for primitive types.
     */
    protected stringifyQuery(query: object | Record<string, unknown>): string;
    private getUserAgent;
    protected defaultIdempotencyKey(): string;
    protected makeStatusError(status: number, error: Object, message: string | undefined, headers: Headers): Errors.APIError;
    buildURL(path: string, query: Record<string, unknown> | null | undefined, defaultBaseURL?: string | undefined): string;
    /**
     * Used as a callback for mutating the given `FinalRequestOptions` object.
     */
    protected prepareOptions(options: FinalRequestOptions): Promise<void>;
    /**
     * Used as a callback for mutating the given `RequestInit` object.
     *
     * This is useful for cases where you want to add certain headers based off of
     * the request properties, e.g. `method` or `url`.
     */
    protected prepareRequest(request: RequestInit, { url, options }: {
        url: string;
        options: FinalRequestOptions;
    }): Promise<void>;
    get<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    post<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    patch<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    put<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    delete<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    private methodRequest;
    request<Rsp>(options: PromiseOrValue<FinalRequestOptions>, remainingRetries?: number | null): APIPromise<Rsp>;
    private makeRequest;
    fetchWithTimeout(url: RequestInfo, init: RequestInit | undefined, ms: number, controller: AbortController): Promise<Response>;
    private shouldRetry;
    private retryRequest;
    private calculateDefaultRetryTimeoutMillis;
    buildRequest(inputOptions: FinalRequestOptions, { retryCount }?: {
        retryCount?: number;
    }): Promise<{
        req: FinalizedRequestInit;
        url: string;
        timeout: number;
    }>;
    private buildHeaders;
    private _makeAbort;
    private buildBody;
    static Supermemory: typeof Supermemory;
    static DEFAULT_TIMEOUT: number;
    static SupermemoryError: typeof Errors.SupermemoryError;
    static APIError: typeof Errors.APIError;
    static APIConnectionError: typeof Errors.APIConnectionError;
    static APIConnectionTimeoutError: typeof Errors.APIConnectionTimeoutError;
    static APIUserAbortError: typeof Errors.APIUserAbortError;
    static NotFoundError: typeof Errors.NotFoundError;
    static ConflictError: typeof Errors.ConflictError;
    static RateLimitError: typeof Errors.RateLimitError;
    static BadRequestError: typeof Errors.BadRequestError;
    static AuthenticationError: typeof Errors.AuthenticationError;
    static InternalServerError: typeof Errors.InternalServerError;
    static PermissionDeniedError: typeof Errors.PermissionDeniedError;
    static UnprocessableEntityError: typeof Errors.UnprocessableEntityError;
    static toFile: typeof Uploads.toFile;
    memories: API.Memories;
    documents: API.Documents;
    search: API.Search;
    settings: API.Settings;
    connections: API.Connections;
}
export declare namespace Supermemory {
    export type RequestOptions = Opts.RequestOptions;
    export { type AddResponse as AddResponse, type ProfileResponse as ProfileResponse, type AddParams as AddParams, type ProfileParams as ProfileParams, };
    export { Memories as Memories, type MemoryForgetResponse as MemoryForgetResponse, type MemoryUpdateMemoryResponse as MemoryUpdateMemoryResponse, type MemoryForgetParams as MemoryForgetParams, type MemoryUpdateMemoryParams as MemoryUpdateMemoryParams, };
    export { Documents as Documents, type DocumentUpdateResponse as DocumentUpdateResponse, type DocumentListResponse as DocumentListResponse, type DocumentAddResponse as DocumentAddResponse, type DocumentBatchAddResponse as DocumentBatchAddResponse, type DocumentDeleteBulkResponse as DocumentDeleteBulkResponse, type DocumentGetResponse as DocumentGetResponse, type DocumentListProcessingResponse as DocumentListProcessingResponse, type DocumentUploadFileResponse as DocumentUploadFileResponse, type DocumentUpdateParams as DocumentUpdateParams, type DocumentListParams as DocumentListParams, type DocumentAddParams as DocumentAddParams, type DocumentBatchAddParams as DocumentBatchAddParams, type DocumentDeleteBulkParams as DocumentDeleteBulkParams, type DocumentUploadFileParams as DocumentUploadFileParams, };
    export { Search as Search, type SearchDocumentsResponse as SearchDocumentsResponse, type SearchExecuteResponse as SearchExecuteResponse, type SearchMemoriesResponse as SearchMemoriesResponse, type SearchDocumentsParams as SearchDocumentsParams, type SearchExecuteParams as SearchExecuteParams, type SearchMemoriesParams as SearchMemoriesParams, };
    export { Settings as Settings, type SettingUpdateResponse as SettingUpdateResponse, type SettingGetResponse as SettingGetResponse, type SettingUpdateParams as SettingUpdateParams, };
    export { Connections as Connections, type ConnectionCreateResponse as ConnectionCreateResponse, type ConnectionListResponse as ConnectionListResponse, type ConnectionConfigureResponse as ConnectionConfigureResponse, type ConnectionDeleteByIDResponse as ConnectionDeleteByIDResponse, type ConnectionDeleteByProviderResponse as ConnectionDeleteByProviderResponse, type ConnectionGetByIDResponse as ConnectionGetByIDResponse, type ConnectionGetByTagResponse as ConnectionGetByTagResponse, type ConnectionImportResponse as ConnectionImportResponse, type ConnectionListDocumentsResponse as ConnectionListDocumentsResponse, type ConnectionResourcesResponse as ConnectionResourcesResponse, type ConnectionCreateParams as ConnectionCreateParams, type ConnectionListParams as ConnectionListParams, type ConnectionConfigureParams as ConnectionConfigureParams, type ConnectionDeleteByIDParams as ConnectionDeleteByIDParams, type ConnectionDeleteByProviderParams as ConnectionDeleteByProviderParams, type ConnectionGetByTagParams as ConnectionGetByTagParams, type ConnectionImportParams as ConnectionImportParams, type ConnectionListDocumentsParams as ConnectionListDocumentsParams, type ConnectionResourcesParams as ConnectionResourcesParams, };
}
//# sourceMappingURL=client.d.mts.map