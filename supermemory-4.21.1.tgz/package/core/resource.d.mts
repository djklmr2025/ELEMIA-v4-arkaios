import type { Supermemory } from "../client.mjs";
export declare abstract class APIResource {
    protected _client: Supermemory;
    constructor(client: Supermemory);
}
//# sourceMappingURL=resource.d.mts.map