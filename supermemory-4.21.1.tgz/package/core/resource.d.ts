import type { Supermemory } from "../client.js";
export declare abstract class APIResource {
    protected _client: Supermemory;
    constructor(client: Supermemory);
}
//# sourceMappingURL=resource.d.ts.map