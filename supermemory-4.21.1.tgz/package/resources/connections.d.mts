import { APIResource } from "../core/resource.mjs";
import { APIPromise } from "../core/api-promise.mjs";
import { RequestOptions } from "../internal/request-options.mjs";
export declare class Connections extends APIResource {
    /**
     * Initialize connection and get authorization URL
     *
     * @example
     * ```ts
     * const connection = await client.connections.create(
     *   'notion',
     * );
     * ```
     */
    create(provider: 'notion' | 'google-drive' | 'onedrive' | 'gmail' | 'github' | 'web-crawler' | 's3', body: ConnectionCreateParams, options?: RequestOptions): APIPromise<ConnectionCreateResponse>;
    /**
     * List all connections
     *
     * @example
     * ```ts
     * const connections = await client.connections.list();
     * ```
     */
    list(body: ConnectionListParams, options?: RequestOptions): APIPromise<ConnectionListResponse>;
    /**
     * Configure resources for a connection (supported providers: GitHub for now)
     *
     * @example
     * ```ts
     * const response = await client.connections.configure(
     *   'connectionId',
     *   { resources: [{ foo: 'bar' }] },
     * );
     * ```
     */
    configure(connectionID: string, body: ConnectionConfigureParams, options?: RequestOptions): APIPromise<ConnectionConfigureResponse>;
    /**
     * Delete a specific connection by ID
     *
     * @example
     * ```ts
     * const response = await client.connections.deleteByID(
     *   'connectionId',
     * );
     * ```
     */
    deleteByID(connectionID: string, params?: ConnectionDeleteByIDParams | null | undefined, options?: RequestOptions): APIPromise<ConnectionDeleteByIDResponse>;
    /**
     * Delete connection for a specific provider and container tags
     *
     * @example
     * ```ts
     * const response = await client.connections.deleteByProvider(
     *   'notion',
     *   { containerTags: ['user_123', 'project_123'] },
     * );
     * ```
     */
    deleteByProvider(provider: 'notion' | 'google-drive' | 'onedrive' | 'gmail' | 'github' | 'web-crawler' | 's3', body: ConnectionDeleteByProviderParams, options?: RequestOptions): APIPromise<ConnectionDeleteByProviderResponse>;
    /**
     * Get connection details with id
     *
     * @example
     * ```ts
     * const response = await client.connections.getByID(
     *   'connectionId',
     * );
     * ```
     */
    getByID(connectionID: string, options?: RequestOptions): APIPromise<ConnectionGetByIDResponse>;
    /**
     * Get connection details with provider and container tags
     *
     * @example
     * ```ts
     * const response = await client.connections.getByTag(
     *   'notion',
     *   { containerTags: ['user_123', 'project_123'] },
     * );
     * ```
     */
    getByTag(provider: 'notion' | 'google-drive' | 'onedrive' | 'gmail' | 'github' | 'web-crawler' | 's3', body: ConnectionGetByTagParams, options?: RequestOptions): APIPromise<ConnectionGetByTagResponse>;
    /**
     * Initiate a manual sync of connections
     *
     * @example
     * ```ts
     * const response = await client.connections.import('notion');
     * ```
     */
    import(provider: 'notion' | 'google-drive' | 'onedrive' | 'gmail' | 'github' | 'web-crawler' | 's3', body: ConnectionImportParams, options?: RequestOptions): APIPromise<string>;
    /**
     * List documents indexed for a provider and container tags
     *
     * @example
     * ```ts
     * const response = await client.connections.listDocuments(
     *   'notion',
     * );
     * ```
     */
    listDocuments(provider: 'notion' | 'google-drive' | 'onedrive' | 'gmail' | 'github' | 'web-crawler' | 's3', body: ConnectionListDocumentsParams, options?: RequestOptions): APIPromise<ConnectionListDocumentsResponse>;
    /**
     * Fetch resources for a connection (supported providers: GitHub for now)
     *
     * @example
     * ```ts
     * const response = await client.connections.resources(
     *   'connectionId',
     * );
     * ```
     */
    resources(connectionID: string, query?: ConnectionResourcesParams | null | undefined, options?: RequestOptions): APIPromise<ConnectionResourcesResponse>;
}
export interface ConnectionCreateResponse {
    id: string;
    authLink: string;
    expiresIn: string;
    redirectsTo?: string;
}
export type ConnectionListResponse = Array<ConnectionListResponse.ConnectionListResponseItem>;
export declare namespace ConnectionListResponse {
    interface ConnectionListResponseItem {
        id: string;
        createdAt: string;
        provider: string;
        /**
         * @deprecated
         */
        containerTags?: Array<string>;
        documentLimit?: number;
        email?: string;
        expiresAt?: string;
        metadata?: {
            [key: string]: unknown;
        };
    }
}
export interface ConnectionConfigureResponse {
    message: string;
    success: boolean;
    webhooksRegistered?: number;
}
export interface ConnectionDeleteByIDResponse {
    id: string;
    provider: string;
}
export interface ConnectionDeleteByProviderResponse {
    id: string;
    provider: string;
}
export interface ConnectionGetByIDResponse {
    id: string;
    createdAt: string;
    provider: string;
    /**
     * @deprecated
     */
    containerTags?: Array<string>;
    documentLimit?: number;
    email?: string;
    expiresAt?: string;
    metadata?: {
        [key: string]: unknown;
    };
}
export interface ConnectionGetByTagResponse {
    id: string;
    createdAt: string;
    provider: string;
    /**
     * @deprecated
     */
    containerTags?: Array<string>;
    documentLimit?: number;
    email?: string;
    expiresAt?: string;
    metadata?: {
        [key: string]: unknown;
    };
}
export type ConnectionImportResponse = string;
export type ConnectionListDocumentsResponse = Array<ConnectionListDocumentsResponse.ConnectionListDocumentsResponseItem>;
export declare namespace ConnectionListDocumentsResponse {
    interface ConnectionListDocumentsResponseItem {
        id: string;
        createdAt: string;
        status: string;
        summary: string | null;
        title: string | null;
        type: string;
        updatedAt: string;
    }
}
export interface ConnectionResourcesResponse {
    resources: Array<{
        [key: string]: unknown;
    }>;
    total_count?: number;
}
export interface ConnectionCreateParams {
    containerTag?: string;
    containerTags?: Array<string>;
    documentLimit?: number;
    metadata?: {
        [key: string]: string | number | boolean;
    } | null;
    redirectUrl?: string;
}
export interface ConnectionListParams {
    /**
     * Optional comma-separated list of container tags to filter documents by
     */
    containerTags?: Array<string>;
}
export interface ConnectionConfigureParams {
    resources: Array<{
        [key: string]: unknown;
    }>;
}
export interface ConnectionDeleteByIDParams {
    /**
     * Whether to also delete documents imported by this connection. Defaults to true.
     */
    deleteDocuments?: string;
}
export interface ConnectionDeleteByProviderParams {
    /**
     * Optional comma-separated list of container tags to filter connections by
     */
    containerTags: Array<string>;
}
export interface ConnectionGetByTagParams {
    /**
     * Comma-separated list of container tags to filter connection by
     */
    containerTags: Array<string>;
}
export interface ConnectionImportParams {
    /**
     * Optional comma-separated list of container tags to filter connections by
     */
    containerTags?: Array<string>;
}
export interface ConnectionListDocumentsParams {
    /**
     * Optional comma-separated list of container tags to filter documents by
     */
    containerTags?: Array<string>;
}
export interface ConnectionResourcesParams {
    page?: number;
    per_page?: number;
}
export declare namespace Connections {
    export { type ConnectionCreateResponse as ConnectionCreateResponse, type ConnectionListResponse as ConnectionListResponse, type ConnectionConfigureResponse as ConnectionConfigureResponse, type ConnectionDeleteByIDResponse as ConnectionDeleteByIDResponse, type ConnectionDeleteByProviderResponse as ConnectionDeleteByProviderResponse, type ConnectionGetByIDResponse as ConnectionGetByIDResponse, type ConnectionGetByTagResponse as ConnectionGetByTagResponse, type ConnectionImportResponse as ConnectionImportResponse, type ConnectionListDocumentsResponse as ConnectionListDocumentsResponse, type ConnectionResourcesResponse as ConnectionResourcesResponse, type ConnectionCreateParams as ConnectionCreateParams, type ConnectionListParams as ConnectionListParams, type ConnectionConfigureParams as ConnectionConfigureParams, type ConnectionDeleteByIDParams as ConnectionDeleteByIDParams, type ConnectionDeleteByProviderParams as ConnectionDeleteByProviderParams, type ConnectionGetByTagParams as ConnectionGetByTagParams, type ConnectionImportParams as ConnectionImportParams, type ConnectionListDocumentsParams as ConnectionListDocumentsParams, type ConnectionResourcesParams as ConnectionResourcesParams, };
}
//# sourceMappingURL=connections.d.mts.map