// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { buildHeaders } from "../internal/headers.mjs";
import { path } from "../internal/utils/path.mjs";
export class Connections extends APIResource {
    /**
     * Initialize connection and get authorization URL
     *
     * @example
     * ```ts
     * const connection = await client.connections.create(
     *   'notion',
     * );
     * ```
     */
    create(provider, body, options) {
        return this._client.post(path `/v3/connections/${provider}`, { body, ...options });
    }
    /**
     * List all connections
     *
     * @example
     * ```ts
     * const connections = await client.connections.list();
     * ```
     */
    list(body, options) {
        return this._client.post('/v3/connections/list', { body, ...options });
    }
    /**
     * Configure resources for a connection (supported providers: GitHub for now)
     *
     * @example
     * ```ts
     * const response = await client.connections.configure(
     *   'connectionId',
     *   { resources: [{ foo: 'bar' }] },
     * );
     * ```
     */
    configure(connectionID, body, options) {
        return this._client.post(path `/v3/connections/${connectionID}/configure`, { body, ...options });
    }
    /**
     * Delete a specific connection by ID
     *
     * @example
     * ```ts
     * const response = await client.connections.deleteByID(
     *   'connectionId',
     * );
     * ```
     */
    deleteByID(connectionID, params = {}, options) {
        const { deleteDocuments } = params ?? {};
        return this._client.delete(path `/v3/connections/${connectionID}`, {
            query: { deleteDocuments },
            ...options,
        });
    }
    /**
     * Delete connection for a specific provider and container tags
     *
     * @example
     * ```ts
     * const response = await client.connections.deleteByProvider(
     *   'notion',
     *   { containerTags: ['user_123', 'project_123'] },
     * );
     * ```
     */
    deleteByProvider(provider, body, options) {
        return this._client.delete(path `/v3/connections/${provider}`, { body, ...options });
    }
    /**
     * Get connection details with id
     *
     * @example
     * ```ts
     * const response = await client.connections.getByID(
     *   'connectionId',
     * );
     * ```
     */
    getByID(connectionID, options) {
        return this._client.get(path `/v3/connections/${connectionID}`, options);
    }
    /**
     * Get connection details with provider and container tags
     *
     * @example
     * ```ts
     * const response = await client.connections.getByTag(
     *   'notion',
     *   { containerTags: ['user_123', 'project_123'] },
     * );
     * ```
     */
    getByTag(provider, body, options) {
        return this._client.post(path `/v3/connections/${provider}/connection`, { body, ...options });
    }
    /**
     * Initiate a manual sync of connections
     *
     * @example
     * ```ts
     * const response = await client.connections.import('notion');
     * ```
     */
    import(provider, body, options) {
        return this._client.post(path `/v3/connections/${provider}/import`, {
            body,
            ...options,
            headers: buildHeaders([{ Accept: 'text/plain' }, options?.headers]),
        });
    }
    /**
     * List documents indexed for a provider and container tags
     *
     * @example
     * ```ts
     * const response = await client.connections.listDocuments(
     *   'notion',
     * );
     * ```
     */
    listDocuments(provider, body, options) {
        return this._client.post(path `/v3/connections/${provider}/documents`, { body, ...options });
    }
    /**
     * Fetch resources for a connection (supported providers: GitHub for now)
     *
     * @example
     * ```ts
     * const response = await client.connections.resources(
     *   'connectionId',
     * );
     * ```
     */
    resources(connectionID, query = {}, options) {
        return this._client.get(path `/v3/connections/${connectionID}/resources`, { query, ...options });
    }
}
//# sourceMappingURL=connections.mjs.map