"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Documents = void 0;
const resource_1 = require("../core/resource.js");
const headers_1 = require("../internal/headers.js");
const uploads_1 = require("../internal/uploads.js");
const path_1 = require("../internal/utils/path.js");
class Documents extends resource_1.APIResource {
    /**
     * Update a document with any content type (text, url, file, etc.) and metadata
     *
     * @example
     * ```ts
     * const document = await client.documents.update('id');
     * ```
     */
    update(id, body, options) {
        return this._client.patch((0, path_1.path) `/v3/documents/${id}`, { body, ...options });
    }
    /**
     * Retrieves a paginated list of documents with their metadata and workflow status
     *
     * @example
     * ```ts
     * const documents = await client.documents.list();
     * ```
     */
    list(body, options) {
        return this._client.post('/v3/documents/list', { body, ...options });
    }
    /**
     * Delete a document by ID or customId
     *
     * @example
     * ```ts
     * await client.documents.delete('id');
     * ```
     */
    delete(id, options) {
        return this._client.delete((0, path_1.path) `/v3/documents/${id}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Add a document with any content type (text, url, file, etc.) and metadata
     *
     * @example
     * ```ts
     * const response = await client.documents.add({
     *   content: 'content',
     * });
     * ```
     */
    add(body, options) {
        return this._client.post('/v3/documents', { body, ...options });
    }
    /**
     * Add multiple documents in a single request. Each document can have any content
     * type (text, url, file, etc.) and metadata
     *
     * @example
     * ```ts
     * const response = await client.documents.batchAdd({
     *   documents: [
     *     {
     *       content:
     *         'This is a detailed article about machine learning concepts...',
     *     },
     *   ],
     * });
     * ```
     */
    batchAdd(body, options) {
        return this._client.post('/v3/documents/batch', { body, ...options });
    }
    /**
     * Bulk delete documents by IDs or container tags
     *
     * @example
     * ```ts
     * const response = await client.documents.deleteBulk();
     * ```
     */
    deleteBulk(body, options) {
        return this._client.delete('/v3/documents/bulk', { body, ...options });
    }
    /**
     * Get a document by ID
     *
     * @example
     * ```ts
     * const document = await client.documents.get('id');
     * ```
     */
    get(id, options) {
        return this._client.get((0, path_1.path) `/v3/documents/${id}`, options);
    }
    /**
     * Get documents that are currently being processed
     *
     * @example
     * ```ts
     * const response = await client.documents.listProcessing();
     * ```
     */
    listProcessing(options) {
        return this._client.get('/v3/documents/processing', options);
    }
    /**
     * Upload a file to be processed
     *
     * @example
     * ```ts
     * const response = await client.documents.uploadFile({
     *   file: fs.createReadStream('path/to/file'),
     * });
     * ```
     */
    uploadFile(body, options) {
        return this._client.post('/v3/documents/file', (0, uploads_1.multipartFormRequestOptions)({ body, ...options }, this._client));
    }
}
exports.Documents = Documents;
//# sourceMappingURL=documents.js.map