"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Memories = void 0;
const resource_1 = require("../core/resource.js");
class Memories extends resource_1.APIResource {
    /**
     * Forget (soft delete) a memory entry. The memory is marked as forgotten but not
     * permanently deleted.
     *
     * @example
     * ```ts
     * const response = await client.memories.forget({
     *   containerTag: 'user_123',
     * });
     * ```
     */
    forget(body, options) {
        return this._client.delete('/v4/memories', { body, ...options });
    }
    /**
     * Update a memory by creating a new version. The original memory is preserved with
     * isLatest=false.
     *
     * @example
     * ```ts
     * const response = await client.memories.updateMemory({
     *   containerTag: 'user_123',
     *   newContent: 'John now prefers light mode',
     * });
     * ```
     */
    updateMemory(body, options) {
        return this._client.patch('/v4/memories', { body, ...options });
    }
}
exports.Memories = Memories;
//# sourceMappingURL=memories.js.map