"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Search = void 0;
const resource_1 = require("../core/resource.js");
class Search extends resource_1.APIResource {
    /**
     * Search memories with advanced filtering
     *
     * @example
     * ```ts
     * const response = await client.search.documents({
     *   q: 'machine learning concepts',
     * });
     * ```
     */
    documents(body, options) {
        return this._client.post('/v3/search', { body, ...options });
    }
    /**
     * Search memories with advanced filtering
     *
     * @example
     * ```ts
     * const response = await client.search.execute({
     *   q: 'machine learning concepts',
     * });
     * ```
     */
    execute(body, options) {
        return this._client.post('/v3/search', { body, ...options });
    }
    /**
     * Search memory entries - Low latency for conversational
     *
     * @example
     * ```ts
     * const response = await client.search.memories({
     *   q: 'machine learning concepts',
     * });
     * ```
     */
    memories(body, options) {
        return this._client.post('/v4/search', { body, ...options });
    }
}
exports.Search = Search;
//# sourceMappingURL=search.js.map