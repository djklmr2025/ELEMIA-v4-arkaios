// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
export class Search extends APIResource {
    /**
     * Search memories with advanced filtering
     *
     * @example
     * ```ts
     * const response = await client.search.documents({
     *   q: 'machine learning concepts',
     * });
     * ```
     */
    documents(body, options) {
        return this._client.post('/v3/search', { body, ...options });
    }
    /**
     * Search memories with advanced filtering
     *
     * @example
     * ```ts
     * const response = await client.search.execute({
     *   q: 'machine learning concepts',
     * });
     * ```
     */
    execute(body, options) {
        return this._client.post('/v3/search', { body, ...options });
    }
    /**
     * Search memory entries - Low latency for conversational
     *
     * @example
     * ```ts
     * const response = await client.search.memories({
     *   q: 'machine learning concepts',
     * });
     * ```
     */
    memories(body, options) {
        return this._client.post('/v4/search', { body, ...options });
    }
}
//# sourceMappingURL=search.mjs.map