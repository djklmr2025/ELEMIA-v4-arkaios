import { APIResource } from "../core/resource.mjs";
import { APIPromise } from "../core/api-promise.mjs";
import { RequestOptions } from "../internal/request-options.mjs";
export declare class Settings extends APIResource {
    /**
     * Update settings for an organization
     */
    update(body: SettingUpdateParams, options?: RequestOptions): APIPromise<SettingUpdateResponse>;
    /**
     * Get settings for an organization
     */
    get(options?: RequestOptions): APIPromise<SettingGetResponse>;
}
export interface SettingUpdateResponse {
    orgId: string;
    orgSlug: string;
    updated: SettingUpdateResponse.Updated;
}
export declare namespace SettingUpdateResponse {
    interface Updated {
        chunkSize?: number | null;
        excludeItems?: string | number | boolean | {
            [key: string]: unknown;
        } | Array<unknown> | null;
        filterPrompt?: string | null;
        githubClientId?: string | null;
        githubClientSecret?: string | null;
        githubCustomKeyEnabled?: boolean | null;
        googleDriveClientId?: string | null;
        googleDriveClientSecret?: string | null;
        googleDriveCustomKeyEnabled?: boolean | null;
        includeItems?: string | number | boolean | {
            [key: string]: unknown;
        } | Array<unknown> | null;
        notionClientId?: string | null;
        notionClientSecret?: string | null;
        notionCustomKeyEnabled?: boolean | null;
        onedriveClientId?: string | null;
        onedriveClientSecret?: string | null;
        onedriveCustomKeyEnabled?: boolean | null;
        shouldLLMFilter?: boolean | null;
    }
}
export interface SettingGetResponse {
    chunkSize?: number | null;
    excludeItems?: string | number | boolean | {
        [key: string]: unknown;
    } | Array<unknown> | null;
    filterPrompt?: string | null;
    githubClientId?: string | null;
    githubClientSecret?: string | null;
    githubCustomKeyEnabled?: boolean | null;
    googleDriveClientId?: string | null;
    googleDriveClientSecret?: string | null;
    googleDriveCustomKeyEnabled?: boolean | null;
    includeItems?: string | number | boolean | {
        [key: string]: unknown;
    } | Array<unknown> | null;
    notionClientId?: string | null;
    notionClientSecret?: string | null;
    notionCustomKeyEnabled?: boolean | null;
    onedriveClientId?: string | null;
    onedriveClientSecret?: string | null;
    onedriveCustomKeyEnabled?: boolean | null;
    shouldLLMFilter?: boolean | null;
}
export interface SettingUpdateParams {
    chunkSize?: number | null;
    excludeItems?: string | number | boolean | {
        [key: string]: unknown;
    } | Array<unknown> | null;
    filterPrompt?: string | null;
    githubClientId?: string | null;
    githubClientSecret?: string | null;
    githubCustomKeyEnabled?: boolean | null;
    googleDriveClientId?: string | null;
    googleDriveClientSecret?: string | null;
    googleDriveCustomKeyEnabled?: boolean | null;
    includeItems?: string | number | boolean | {
        [key: string]: unknown;
    } | Array<unknown> | null;
    notionClientId?: string | null;
    notionClientSecret?: string | null;
    notionCustomKeyEnabled?: boolean | null;
    onedriveClientId?: string | null;
    onedriveClientSecret?: string | null;
    onedriveCustomKeyEnabled?: boolean | null;
    shouldLLMFilter?: boolean | null;
}
export declare namespace Settings {
    export { type SettingUpdateResponse as SettingUpdateResponse, type SettingGetResponse as SettingGetResponse, type SettingUpdateParams as SettingUpdateParams, };
}
//# sourceMappingURL=settings.d.mts.map