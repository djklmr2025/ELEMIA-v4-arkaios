"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Settings = void 0;
const resource_1 = require("../core/resource.js");
class Settings extends resource_1.APIResource {
    /**
     * Update settings for an organization
     */
    update(body, options) {
        return this._client.patch('/v3/settings', { body, ...options });
    }
    /**
     * Get settings for an organization
     */
    get(options) {
        return this._client.get('/v3/settings', options);
    }
}
exports.Settings = Settings;
//# sourceMappingURL=settings.js.map