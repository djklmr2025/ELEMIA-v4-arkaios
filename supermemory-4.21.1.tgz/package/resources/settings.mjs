// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
export class Settings extends APIResource {
    /**
     * Update settings for an organization
     */
    update(body, options) {
        return this._client.patch('/v3/settings', { body, ...options });
    }
    /**
     * Get settings for an organization
     */
    get(options) {
        return this._client.get('/v3/settings', options);
    }
}
//# sourceMappingURL=settings.mjs.map