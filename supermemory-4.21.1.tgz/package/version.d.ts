export declare const VERSION = "4.21.1";
//# sourceMappingURL=version.d.ts.map